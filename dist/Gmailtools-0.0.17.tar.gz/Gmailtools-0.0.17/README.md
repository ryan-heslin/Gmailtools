*Gmailtools*

This package implements a command-line interface for using the Gmail API to search for and send emails.
